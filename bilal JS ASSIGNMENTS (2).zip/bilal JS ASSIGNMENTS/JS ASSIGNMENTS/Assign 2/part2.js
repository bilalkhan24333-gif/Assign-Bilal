// 1. Ask the user for their age. If the age is 18 or more, show an alert: "You are an adult.", else show: "You are a minor."
//SOLN:
// let age = +prompt('Enter your age:')
// if (age >= 18){
//     alert('You are an adult.')
// }
// else{
//     alert('You are a minor.')
// }

// 2. Ask the user to enter a number. If it's positive, log: "Positive number"; else log: "Not positive".
//SOLN:
// let num = +prompt('Enter a number:')
// if (num > 0){
//     console.log('Positive number')
// }
// else{
//     console.log('Not positive')
// }

// 3. Ask the user for a number. If it’s even, alert: "Even number"; else alert: "Odd number".
//SOLN:
// let num = +prompt('Enter a number:')
// if (num % 2 === 0){
//     alert('Even number')
// }
// else{
//     alert('Odd number')
// }

// 4. Ask for a username. If the username is "admin", display "Welcome, admin!"; else display "Access denied."
//SOLN:
// let name = prompt('Enter username:')
// if (name === 'admin'){
//     alert('Welcome, admin!')
// }
// else{
//     alert('Access denied.')
// }

// 5. Ask for two numbers. If they are equal, log "Both numbers are the same"; otherwise, log "The numbers are different".
//SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// if (num1 === num2){
//     console.log('Both numbers are the same')
// }
// else{
//     console.log('The numbers are different')
// }

// 6. Ask the user to enter two numbers. Check which one is larger and alert: "First is larger" or "Second is larger".
//SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// if (num1 > num2){
//     alert('First is larger')
// }
// else{
//     alert('Second is larger')
// }

// 7. Ask for a number. If it's greater than 100, alert "Too big!", else alert "Within range".
//SOLN:
// let num = +prompt('Enter a number:')
// if (num > 100){
//     alert('Too big!')
// }
// else{
//     alert('Within range')
// }

// 8. Ask for a score. If it’s 50 or higher, log "You passed!", else log "You failed."
//SOLN:
// let score = +prompt('Enter your score:')
// if (score >= 50){
//     console.log('You passed!')
// }
// else{
//     console.log('You failed.')
// }

// 9. Ask the user to enter a temperature. If it’s over 30, alert "It's hot!"; else alert "It's not hot."
//SOLN:
// let temp = +prompt('Enter temperature:')
// if (temp > 30){
//     alert("It's hot!")
// }
// else{
//     alert("It's not hot.")
// }

// 10. Ask the user to enter a number. If it's 0, alert "Zero"; if it’s not zero, alert "Not zero".
//SOLN:
// let num = +prompt('Enter a number:')
// if (num === 0){
//     alert('Zero')
// }
// else{
//     alert('Not zero')
// }

// 11. Ask the user for their age. If it's 60 or more, log "You are a senior citizen.", else log "You are not a senior."
//SOLN:
// let age = +prompt('Enter your age:')
// if (age >= 60){
//     console.log('You are a senior citizen.')
// }
// else{
//     console.log('You are not a senior.')
// }

// 12. Ask the user for their name. If the name is "Alice", alert "Hi, Alice!"; else alert "You're not Alice!"
//SOLN:
// let name = prompt('Enter your name:')
// if (name === 'Alice'){
//     alert('Hi, Alice!')
// }
// else{
//     alert("You're not Alice!")
// }

// 13. Ask the user for a password. If it matches "12345", log "Correct password"; else log "Wrong password".
//SOLN:
// let pass = prompt('Enter password:')
// if (pass === '12345'){
//     console.log('Correct password')
// }
// else{
//     console.log('Wrong password')
// }

// 14. Ask the user for the current hour (0–23). If it’s less than 12, alert "Good morning!"; else alert "Good afternoon!"
//SOLN:
// let hour = +prompt('Enter current hour (0-23):')
// if (hour < 12){
//     alert('Good morning!')
// }
// else{
//     alert('Good afternoon!')
// }

// 15. Ask the user to enter a number. If it's divisible by 5, log "Divisible by 5"; else log "Not divisible by 5".
//SOLN:
// let num = +prompt('Enter a number:')
// if (num % 5 === 0){
//     console.log('Divisible by 5')
// }
// else{
//     console.log('Not divisible by 5')
// }

// 16. Ask the user if they want to play a game (yes/no). If they type "yes", alert "Let's play!"; else alert "Maybe next time!"
//SOLN:
// let play = prompt('Do you want to play a game? (yes/no)')
// if (play === 'yes'){
//     alert("Let's play!")
// }
// else{
//     alert('Maybe next time!')
// }

// 17. Ask the user for a color. If the color is "blue", log "Cool choice!"; else log "Interesting color!"
//SOLN:
// let color = prompt('Enter a color:')
// if (color === 'blue'){
//     console.log('Cool choice!')
// }
// else{
//     console.log('Interesting color!')
// }

// 18. Ask for the day of the week. If it’s "Sunday", alert "Weekend!"; else alert "Weekday".
//SOLN:
// let day = prompt('Enter day of the week:')
// if (day === 'Sunday'){
//     alert('Weekend!')
// }
// else{
//     alert('Weekday')
// }

// 19. Ask the user to enter a fruit. If it's "banana" or "apple", alert "We have that!"; else alert "Sorry, out of stock."
//SOLN:
// let fruit = prompt('Enter a fruit:')
// if (fruit === 'banana' || fruit === 'apple'){
//     alert('We have that!')
// }
// else{
//     alert('Sorry, out of stock.')
// }

// 20. Ask the user to type "start" to begin. If they do, alert "Game started!"; else alert "Waiting for input..."
//SOLN:
// let text = prompt('Type "start" to begin:')
// if (text === 'start'){
//     alert('Game started!')
// }
// else{
//     alert('Waiting for input...')
// }