// Assignment 1: Welcome Message
// Objective: Use prompt() to ask for the user's name. Use alert() to display: "Welcome, [name]!"
// SOLN:
// let name = prompt('Enter your name:')
// alert('Welcome, ' + name + '!')

// Assignment 2: Age Message
// Objective: Ask the user for their name and age using prompt(). Log this message in the console: "[name] is [age] years old."
// SOLN:
// let name = prompt('Enter your name:')
// let age = prompt('Enter your age:')
// console.log(name + ' is ' + age + ' years old.')

// Assignment 3: Favorite Color
// Objective: Ask the user for their favorite color. Show an alert like: "Wow! [color] is a nice color!"
// SOLN:
// let color = prompt('Enter your favorite color:')
// alert('Wow! ' + color + ' is a nice color!')

// Assignment 4: Simple Math Sentence
// Objective: Ask the user for two numbers using prompt(). Show a sentence in the console like: "The result of 4 + 5 is 9."
// SOLN:
// let num1 = prompt('Enter first number:')
// let num2 = prompt('Enter second number:')
// console.log('The result of ' + num1 + ' + ' + num2 + ' is ' + (num1 + num2))

// Assignment 5: About Me Summary
// Objective: Ask the user for their name, hobby, and country using prompt(). Show an alert like: "Hi, I'm [name] from [country], and I love [hobby]!"
// SOLN:
// let name = prompt('Enter your name:')
// let hobby = prompt('Enter your hobby:')
// let country = prompt('Enter your country:')
// alert("Hi, I'm " + name + ' from ' + country + ', and I love ' + hobby + '!')