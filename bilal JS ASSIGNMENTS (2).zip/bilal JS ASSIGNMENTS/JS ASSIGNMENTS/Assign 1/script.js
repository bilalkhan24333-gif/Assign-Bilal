// 1. Speed Limit Warning
// Given a speed, print:
// "Too slow" if below 30
// "Safe speed" if between 30 and 60
// "Speeding" if between 61 and 100
// "Dangerously fast" if over 100

// SOLN:
// let speed = +prompt('Enter the speed!!')
// if (speed < 30){
//     console.log('Too Slow')
// }
// else if (speed >= 30 && speed < 60){
//     console.log('Safe Speed')
// }
// else{
//     console.log('Dangerously Fast')
// }

// 2. Library Book Return Fine
// Given number of late days, calculate the fine:

// 0 days: $0
// 1–5 days: $1 per day
// 6–10 days: $2 per day
// 11+ days: $5 per day

// SOLN:
// let days = +prompt('Enter number of late days:')
// if (days === 0){
//     console.log('Fine: $0')
// }
// else if (days >= 1 && days <= 5){
//     console.log('Fine: $' + (days * 1))
// }
// else if (days >= 6 && days <= 10){
//     console.log('Fine: $' + (days * 2))
// }
// else{
//     console.log('Fine: $' + (days * 5))
// }

// 3. Event Entry Eligibility
// Check if a person (with age and ticket) can enter:

// Must be 18 or older
// Must have a valid ticket

// SOLN:
// let age = +prompt('Enter your age:')
// let hasTicket = confirm('Do you have a valid ticket? (OK for yes, Cancel for no)')
// if (age >= 18 && hasTicket){
//     console.log('Can enter')
// }
// else{
//     console.log('Cannot enter')
// }

// 4. Smartphone Battery Status
// Given battery percentage, print:

// 80–100: "Fully charged"
// 50–79: "Good battery"
// 20–49: "Low battery"
// Below 20: "Charge now!"

// SOLN:
// let battery = +prompt('Enter battery percentage:')
// if (battery >= 80 && battery <= 100){
//     console.log('Fully charged')
// }
// else if (battery >= 50 && battery <= 79){
//     console.log('Good battery')
// }
// else if (battery >= 20 && battery <= 49){
//     console.log('Low battery')
// }
// else{
//     console.log('Charge now!')
// }

// 5. Discount Eligibility
// Given customer type and age, apply discount:

// Student: 20%
// Senior (60+): 30%
// Others: 0%

// SOLN:
// let type = prompt('Enter customer type (Student/Senior/Other):')
// let age = +prompt('Enter age:')
// if (type === 'Student'){
//     console.log('20% Discount')
// }
// else if (age >= 60 || type === 'Senior'){
//     console.log('30% Discount')
// }
// else{
//     console.log('0% Discount')
// }

// 6. Clothing Recommendation
// Based on temperature (°C), suggest clothing:

// Below 10: "Heavy jacket"
// 10–20: "Sweater"
// 21–30: "T-shirt"
// Above 30: "Light clothes"

// SOLN:
// let temp = +prompt('Enter temperature in °C:')
// if (temp < 10){
//     console.log('Heavy jacket')
// }
// else if (temp >= 10 && temp <= 20){
//     console.log('Sweater')
// }
// else if (temp >= 21 && temp <= 30){
//     console.log('T-shirt')
// }
// else{
//     console.log('Light clothes')
// }

// 7. Water Intake Reminder
// Based on activity level, suggest water intake:

// Sedentary: 2L
// Moderate: 2.5L
// Active: 3L+

// SOLN:
// let activity = prompt('Enter activity level (Sedentary/Moderate/Active):')
// if (activity === 'Sedentary'){
//     console.log('2L')
// }
// else if (activity === 'Moderate'){
//     console.log('2.5L')
// }
// else if (activity === 'Active'){
//     console.log('3L+')
// }
// else{
//     console.log('Invalid activity level')
// }

// 8. Exam Result Evaluation
// Given three subject marks, print:

// "Pass" if all marks are 40 or above
// "Fail" if any mark is below 40

// SOLN:
// let mark1 = +prompt('Enter marks for subject 1:')
// let mark2 = +prompt('Enter marks for subject 2:')
// let mark3 = +prompt('Enter marks for subject 3:')
// if (mark1 >= 40 && mark2 >= 40 && mark3 >= 40){
//     console.log('Pass')
// }
// else{
//     console.log('Fail')
// }

// 9. App Theme Selection
// Based on time of day (0–23), select theme:

// 6–17: Light Mode
// Otherwise: Dark Mode

// SOLN:
// let time = +prompt('Enter time of day (0-23):')
// if (time >= 6 && time <= 17){
//     console.log('Light Mode')
// }
// else{
//     console.log('Dark Mode')
// }

// 10. Meal Type Identifier
// Based on time of day (0–23), identify meal:

// 6–10: Breakfast
// 12–14: Lunch
// 18–21: Dinner
// Any other time: Snack

// SOLN:
// let time = +prompt('Enter time of day (0-23):')
// if (time >= 6 && time <= 10){
//     console.log('Breakfast')
// }
// else if (time >= 12 && time <= 14){
//     console.log('Lunch')
// }
// else if (time >= 18 && time <= 21){
//     console.log('Dinner')
// }
// else{
//     console.log('Snack')
// }