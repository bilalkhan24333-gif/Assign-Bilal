// Arithmetic Operator Tasks

// 1. Ask the user to enter two numbers. Show the result of adding them using alert().
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// alert('Sum: ' + (num1 + num2))

// 2. Ask for two numbers. Subtract the second number from the first and log the result to the console.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// console.log('Difference: ' + (num1 - num2))

// 3. Ask for two numbers. Multiply them and display the answer in an alert.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// alert('Product: ' + (num1 * num2))

// 4. Ask the user for two numbers. Divide the first by the second and log the result.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// console.log('Division: ' + (num1 / num2))

// 5. Ask the user for two numbers and show the remainder when the first is divided by the second (use %).
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// alert('Remainder: ' + (num1 % num2))


// Assignment Operator Tasks

// 6. Create a variable with the value 10. Add 5 to it using += and log the new value.
// SOLN:
// let x = 10
// x += 5
// console.log(x)

// 7. Create a variable with the value 20. Subtract 4 from it using -= and alert the result.
// SOLN:
// let x = 20
// x -= 4
// alert(x)

// 8. Create a variable with the value 6. Multiply it by 3 using *= and display the result.
// SOLN:
// let x = 6
// x *= 3
// alert(x)

// 9. Set a variable to 50. Divide it by 2 using /= and log the final value.
// SOLN:
// let x = 50
// x /= 2
// console.log(x)

// 10. Create a variable, assign it a value from prompt(), then increase it by 10 and show the result.
// SOLN:
// let x = +prompt('Enter a number:')
// x += 10
// alert(x)


// Comparison Operator Tasks

// 11. Ask the user for two numbers. Use > to check if the first number is greater than the second, then log the result (true/false).
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// console.log(num1 > num2)

// 12. Ask the user for two numbers. Use < to check if the first number is less than the second, then alert the result.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// alert(num1 < num2)

// 13. Ask the user for a number. Use == to check if it equals 100 and log the result.
// SOLN:
// let num = +prompt('Enter a number:')
// console.log(num == 100)

// 14. Ask the user for a number. Use === to check if it is exactly equal to the string "100" and log the result.
// SOLN:
// let val = prompt('Enter a value:')
// console.log(val === '100')

// 15. Ask the user for two numbers. Use != to check if they are not equal and alert the result.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// alert(num1 != num2)

// 16. Ask the user for two numbers. Use !== to check if they are not strictly equal and log the result.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// console.log(num1 !== num2)

// 17. Ask for two numbers and check if the first is greater than or equal to the second. Display result using alert.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// alert(num1 >= num2)

// 18. Ask for two numbers and check if the first is less than or equal to the second. Show result in the console.
// SOLN:
// let num1 = +prompt('Enter first number:')
// let num2 = +prompt('Enter second number:')
// console.log(num1 <= num2)


// Logical Operator Tasks

// 19. Ask the user for age and country. Use && to check if age is over 18 and country is "USA". Log the result.
// SOLN:
// let age = +prompt('Enter your age:')
// let country = prompt('Enter your country:')
// console.log(age > 18 && country === 'USA')

// 20. Ask the user to enter a color and a shape. Use || to check if the color is "red" or the shape is "circle". Show the result in an alert.
// SOLN:
// let color = prompt('Enter a color:')
// let shape = prompt('Enter a shape:')
// alert(color === 'red' || shape === 'circle')